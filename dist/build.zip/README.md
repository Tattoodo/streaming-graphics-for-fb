# streaming likes

## Installation

    npm install
    
and 

    bower install
    
to install Express, AngularJS and other dependencies

### Run the dashboard on Windows

first run the NodeJS program, then start chrome in app mode

    chrome.exe --app=http://localhost:8080

### Run the dashboard on Mac OS

first run the NodeJS program, then start chrome in app mode

    cd /Applications/Google\ Chrome.app/Contents/MacOS; ./Google\ Chrome --app=http://localhost:8080
