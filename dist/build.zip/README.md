# streaming likes

## Installation

    npm install

to install Express, AngularJS and other dependencies

### Run the dashboard

first run the NodeJS program

    npm start

then, in a new terminal, start chrome in app mode with this command (for Mac OS)

    /Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --app=http://localhost:8080

on windows, start chrome this way

    chrome.exe --app=http://localhost:8080
