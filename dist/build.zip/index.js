// just a proxy
const path = require(`path`)

require(path.normalize(path.join(__dirname, `/server/index`)))

// test

